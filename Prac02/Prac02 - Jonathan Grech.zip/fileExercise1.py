out_file = open("name.txt", "w")
name = input("What is your name? ")
out_file.write(name)
out_file.close()