

print('hello world')